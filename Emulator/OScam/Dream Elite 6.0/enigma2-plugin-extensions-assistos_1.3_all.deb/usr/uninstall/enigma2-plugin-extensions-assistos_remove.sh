#!/bin/sh
dpkg -r enigma2-plugin-extensions-assistos
exit 0

