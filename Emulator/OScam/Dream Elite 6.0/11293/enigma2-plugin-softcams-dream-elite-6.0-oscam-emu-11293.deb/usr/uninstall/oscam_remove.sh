#!/bin/sh
dpkg -r emu-oscam
dpkg -r /etc/tuxbox/config/oscam.*
dpkg -r /etc/tuxbox/config/SoftCam.*
dpkg -r /usr/uninstall/oscam_remove.sh
exit 0
